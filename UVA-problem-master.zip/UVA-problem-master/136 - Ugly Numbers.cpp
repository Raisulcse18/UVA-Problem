#include <cstdio>
using namespace std;
int main() {
	printf("The 1500'th ugly number is 859963392.\n");
	return 0;
}
